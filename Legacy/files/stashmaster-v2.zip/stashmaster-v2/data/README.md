# Dossier Data

Ce dossier contient toutes les données sauvegardées par StashMaster V2.

## Structure

```
data/
├── performers/          # JSON files des performers
│   ├── performer_1.json
│   ├── performer_2.json
│   └── ...
│
└── database.sqlite     # Base de données (futur)
```

## Format JSON des Performers

```json
{
  "name": "Performer Name",
  "aliases": ["Alias 1", "Alias 2"],
  "birthdate": "January 1, 1990",
  "birthplace": "City, Country",
  "ethnicity": "Caucasian",
  "hair_color": "Blonde",
  "eye_color": "Blue",
  "height": "170 cm",
  "weight": "55 kg",
  "measurements": "34DD-25-36",
  "tattoos": "Description of tattoos",
  "piercings": "Description of piercings",
  "career_length": "2010-",
  "tags": ["Tag1", "Tag2", "Tag3"],
  "urls": [
    "https://source1.com/...",
    "https://source2.com/..."
  ],
  "trivia": "Interesting facts...",
  "awards": "Awards and nominations...",
  "bio": "Full biography (3000 characters)..."
}
```

## Sauvegarde et Restauration

### Sauvegarde manuelle
Copiez simplement le dossier `data/` pour créer une sauvegarde.

### Restauration
Remplacez le dossier `data/` par votre sauvegarde.

## Notes

- Les fichiers JSON sont encodés en UTF-8
- Les noms de fichiers sont en minuscules avec underscores
- La base de données SQLite sera ajoutée dans une version future
